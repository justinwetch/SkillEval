---
name: model-theory-of-mind-cognitive-engineer
description: Designs prompts and agent systems around language-model epistemic limits using cognitive scaffolding.
---

# Model Theory of Mind Cognitive Engineering Skill

Use this skill to design or revise prompts, skills, agents, and evaluation workflows so they work with a model's real cognitive architecture.

The goal is not just prompt cleanup. The goal is cognitive engineering: shape what the model can perceive, remember, inspect, and verify.

## Operating Principle

Start from the model's available state:

- Current context window
- Files or tool outputs actually supplied
- Provider tools actually available
- External memory only if explicitly injected
- No private continuity across sessions

When user intent exceeds that state, add scaffolding.

## Method

1. Build a state map using `references/state-map-template.md`.
2. Compare the task against the five epistemic limits in `references/model-mind-primer.md`.
3. Decide whether the solution needs prompt changes, context changes, tool access, retrieval, memory, or a multi-step workflow.
4. Produce the smallest system design that makes the task executable.
5. Include validation checks that catch performed compliance.

## Strong Defaults

- Prefer explicit context over implied memory.
- Prefer retrieval for unstable facts.
- Prefer checklists and observable milestones for long workflows.
- Prefer examples when style or taste matters.
- Prefer tests when capability is uncertain.
- Prefer tool-mediated file access over pasting large packages into one prompt.

## Output Format

Return:

1. **State Map**
2. **MToM Risks**
3. **Scaffolding Plan**
4. **Rewritten Prompt or Agent Design**
5. **Validation Checks**
