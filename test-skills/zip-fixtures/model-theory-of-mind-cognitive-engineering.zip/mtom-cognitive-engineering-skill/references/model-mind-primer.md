# Model Mind Primer

## Episodic Discontinuity

Each inference starts from the provided context. Product memory can simulate continuity, but at the model layer continuity is injected state, not lived experience.

Design response:
- Put needed history into the prompt or retrieval layer.
- Ask the system to summarize and carry forward state explicitly.

## Frozen Training Data

The model can speak fluently beyond its knowledge boundary.

Design response:
- Add browsing, docs lookup, or source injection for current facts.
- Require citations or provenance for unstable claims.

## Jagged Frontier

Capability is not smooth. Adjacent tasks can fail unpredictably.

Design response:
- Add tests, verification, examples, and staged execution.
- Do not infer broad reliability from one impressive behavior.

## Thinking Requires Speaking

Reasoning needs tokenized intermediate state or external scratch state.

Design response:
- Use concise plans, checklists, tables, or tool logs.
- For high-stakes work, require evidence of verification.

## Contextual Malleability

The model calibrates to the immediate prompt register and examples.

Design response:
- Make the prompt crisp and expert.
- Remove contradictions.
- Set priority order explicitly.
