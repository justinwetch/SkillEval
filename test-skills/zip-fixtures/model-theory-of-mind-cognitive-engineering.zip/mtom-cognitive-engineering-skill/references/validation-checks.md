# Validation Checks

Use these checks to detect performed compliance without substance.

## Access Check

Ask: Did the model actually have access to the information it claimed to use?

## State Check

Ask: Does the task require memory that was not supplied?

## Tool Check

Ask: Did the workflow require a tool call or file read that never happened?

## Specificity Check

Ask: Are recommendations grounded in the supplied task, or are they generic?

## Freshness Check

Ask: Could this fact have changed since training?

## Verification Check

Ask: What observable artifact proves completion?
