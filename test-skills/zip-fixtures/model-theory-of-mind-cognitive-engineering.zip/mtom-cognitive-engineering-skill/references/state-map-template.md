# State Map Template

Use this table before designing the prompt or workflow.

| Question | Answer |
| --- | --- |
| What information is in the current context? | |
| What information is assumed but absent? | |
| Which facts may be stale? | |
| Which tools can the model actually call? | |
| Which files can the model actually inspect? | |
| What needs external memory or retrieval? | |
| What needs visible intermediate reasoning or state? | |
| What validation proves the model did the real work? | |

## Scaffold Types

- Context injection
- Retrieval
- File access
- Tool execution
- Scratchpad or checklist
- Test harness
- Human confirmation gate
- Stored state summary
