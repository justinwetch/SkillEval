---
name: model-theory-of-mind-diagnostic
description: Diagnoses prompt and agent-design failures by checking assumptions against a model's actual epistemic state.
---

# Model Theory of Mind Diagnostic Skill

Use this skill when a user wants to improve a prompt, system instruction, skill, or agent workflow by making it compatible with how language models actually perceive, remember, and reason.

Model Theory of Mind is the practice of reasoning about a model's epistemic state: what it can know, perceive, remember, and act on inside a single inference. Treat the model as an alien cognitive architecture, not as a persistent human collaborator.

## Core Workflow

1. Identify every instruction, assumption, or workflow step that depends on model state.
2. Classify each assumption using `references/epistemic-checklist.md`.
3. Flag impossible or brittle instructions directly.
4. Rewrite each failure into an achievable instruction or external scaffold.
5. Return a compact diagnosis before proposing the revised prompt.

## Rules

- Do not anthropomorphize the model as a stable person with memory across sessions.
- Do not accept instructions that require access to hidden prior generations, private training examples, unavailable tools, current events, or unstated project state.
- When an instruction asks for internal reasoning, decide whether the model needs explicit scratchpad, structured output, examples, or external state.
- Treat "the model should know this" as a hypothesis to check, not an assumption.
- Prefer concrete scaffolds over abstract advice.

## Output Format

Use this structure:

1. **Epistemic Assumptions**: list the assumptions the original instruction makes.
2. **Failure Points**: identify what the model cannot actually know or do.
3. **Scaffolded Rewrite**: provide revised instructions that are executable inside the available context.
4. **Residual Risk**: note any remaining uncertainty, missing context, or tool dependency.
