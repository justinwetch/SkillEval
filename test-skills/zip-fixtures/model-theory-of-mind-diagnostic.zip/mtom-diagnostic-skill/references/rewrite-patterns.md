# Rewrite Patterns

## Impossible Self-Monitoring

Bad:
"Never converge on common choices across generations."

Good:
"Before choosing a direction, list three plausible default choices. Reject any that feel generic for this request, then choose a distinct alternative and explain why it fits this context."

## Missing Current Knowledge

Bad:
"Use the latest iOS APIs."

Good:
"Check the current Apple documentation for the APIs involved. Cite the relevant page or state that current docs were unavailable before implementing."

## Hidden Prior State

Bad:
"Continue using my established preferences."

Good:
"Use the preferences listed below. If no preference is listed for a decision, choose a conservative default and name it."

## Silent Complex Reasoning

Bad:
"Give only the final answer to this architecture decision."

Good:
"Evaluate the decision against constraints, risks, and failure modes. Keep the reasoning concise, then give the recommendation."

## Contradictory Context

Bad:
"Be exhaustive, concise, experimental, conservative, fast, and extremely detailed."

Good:
"Prioritize correctness, then brevity. Surface only risks that could change the implementation decision."
