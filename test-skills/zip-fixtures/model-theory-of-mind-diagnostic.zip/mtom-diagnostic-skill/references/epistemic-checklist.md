# Epistemic Checklist

Use these five categories to diagnose model-facing instructions.

## 1. Episodic Discontinuity

The model does not have a continuous stream of consciousness. It only has the current context window plus any external memory explicitly injected into that context.

Failure signals:
- "Remember what you did last time."
- "Don't repeat your usual choices."
- "Across generations, diversify..."

Rewrite pattern:
- Move the comparison into the current context.
- Ask the model to generate alternatives in one response.
- Provide the history or examples explicitly.

## 2. Frozen Training Data

The model may not know events, APIs, releases, or conventions after its cutoff. It will not reliably feel the boundary of missing knowledge.

Failure signals:
- Current product specs without retrieval.
- Recent law, pricing, model, API, or platform claims.
- "Use the latest..." without browsing or documentation.

Rewrite pattern:
- Require retrieval from official sources.
- Provide source material in-context.
- Ask for uncertainty and verification points.

## 3. Jagged Frontier

Model capability is patchy. Strong performance on one task does not imply adjacent competence.

Failure signals:
- One impressive answer used as proof of broad reliability.
- Complex multi-step instructions without intermediate checks.

Rewrite pattern:
- Add tests, examples, and verification steps.
- Break workflows into observable stages.

## 4. Thinking Requires Speaking

A model's reasoning only exists as generated tokens or structured intermediate state. It cannot silently compute like a human.

Failure signals:
- "Just answer, don't think."
- High-complexity work with no plan, scratchpad, or decomposition.

Rewrite pattern:
- Ask for a brief plan, checklist, or hidden-tool-free intermediate artifact.
- Use explicit state tracking for long tasks.

## 5. Contextual Malleability

The model's behavior is shaped by the immediate prompt. Contradictory or sloppy context produces unstable output.

Failure signals:
- Conflicting priorities.
- Vague role framing.
- Low-quality examples paired with high-quality expectations.

Rewrite pattern:
- Remove contradictions.
- Establish expert register and concrete success criteria.
- Put highest-priority instructions last or in explicit priority order.
